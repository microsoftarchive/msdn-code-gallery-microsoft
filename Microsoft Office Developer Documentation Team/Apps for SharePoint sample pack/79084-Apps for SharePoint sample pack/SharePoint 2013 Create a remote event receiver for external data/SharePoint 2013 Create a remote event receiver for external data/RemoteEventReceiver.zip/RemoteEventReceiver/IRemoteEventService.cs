using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Diagnostics.CodeAnalysis;

namespace Contoso.Test
{
    /// <summary>
    /// 
    /// </summary>
    public enum SPRemoteEventType
    {
        // Before Item Events
        /// <summary>
        /// 
        /// </summary>
        ItemAdding = 1,//
        /// <summary>
        /// 
        /// </summary>
        ItemUpdating = 2,//
        /// <summary>
        /// 
        /// </summary>
        ItemDeleting = 3,//
        /// <summary>
        /// 
        /// </summary>
        ItemCheckingIn = 4,//
        /// <summary>
        /// 
        /// </summary>
        ItemCheckingOut = 5,//
        /// <summary>
        /// 
        /// </summary>
        ItemUncheckingOut = 6,//
        /// <summary>
        /// 
        /// </summary>
        ItemAttachmentAdding = 7,//
        /// <summary>
        /// 
        /// </summary>
        ItemAttachmentDeleting = 8,//
        /// <summary>
        /// 
        /// </summary>
        ItemFileMoving = 9,//

        // Before List Events
        /// <summary>
        /// 
        /// </summary>
        FieldAdding = 101,//
        /// <summary>
        /// 
        /// </summary>
        FieldUpdating = 102,//
        /// <summary>
        /// 
        /// </summary>
        FieldDeleting = 103,//
        /// <summary>
        /// 
        /// </summary>
        ListAdding = 104,//
        /// <summary>
        /// 
        /// </summary>
        ListDeleting = 105,//

        // Before Web Events
        /// <summary>
        /// 
        /// </summary>
        SiteDeleting = 201,//
        /// <summary>
        /// 
        /// </summary>
        WebDeleting = 202,//
        /// <summary>
        /// 
        /// </summary>
        WebMoving = 203,//
        /// <summary>
        /// 
        /// </summary>
        WebAdding = 204,//

        // After Item Events
        /// <summary>
        /// 
        /// </summary>
        ItemAdded = 10001,//
        /// <summary>
        /// 
        /// </summary>
        ItemUpdated = 10002,//
        /// <summary>
        /// 
        /// </summary>
        ItemDeleted = 10003,//
        /// <summary>
        /// 
        /// </summary>
        ItemCheckedIn = 10004,//
        /// <summary>
        /// 
        /// </summary>
        ItemCheckedOut = 10005,//
        /// <summary>
        /// 
        /// </summary>
        ItemUncheckedOut = 10006,//
        /// <summary>
        /// 
        /// </summary>
        ItemAttachmentAdded = 10007,//
        /// <summary>
        /// 
        /// </summary>
        ItemAttachmentDeleted = 10008,//
        /// <summary>
        /// 
        /// </summary>
        ItemFileMoved = 10009,//
        /// <summary>
        /// 
        /// </summary>
        ItemFileConverted = 10010,//
        // After List Events
        /// <summary>
        /// 
        /// </summary>
        FieldAdded = 10101,//
        /// <summary>
        /// 
        /// </summary>
        FieldUpdated = 10102,//
        /// <summary>
        /// 
        /// </summary>
        FieldDeleted = 10103,//
        /// <summary>
        /// 
        /// </summary>
        ListAdded = 10104,//
        /// <summary>
        /// 
        /// </summary>
        ListDeleted = 10105,//
        // After Web Events
        /// <summary>
        /// 
        /// </summary>
        SiteDeleted = 10201,//
        /// <summary>
        /// 
        /// </summary>
        WebDeleted = 10202,//
        /// <summary>
        /// 
        /// </summary>
        WebMoved = 10203,//
        /// <summary>
        /// 
        /// </summary>
        WebProvisioned = 10204,//
        /// <summary>
        /// 
        /// </summary>
        EntityInstanceAdded = 10601,//
        /// <summary>
        /// 
        /// </summary>
        EntityInstanceUpdated = 10602,//
        /// <summary>
        /// 
        /// </summary>
        EntityInstanceDeleted = 10603,//

    };
    /// <summary>
    /// 
    /// </summary>
    public enum SPRemoteEventServiceStatus
    {
        /// <summary>
        /// 
        /// </summary>
        Continue,//
        /// <summary>
        /// 
        /// </summary>
        CancelNoError,//
        /// <summary>
        /// 
        /// </summary>
        CancelWithError,//
        /// <summary>
        /// 
        /// </summary>
        CancelWithRedirectUrl//

    }

    /// <summary>
    /// 
    /// </summary>
    [DataContract(Namespace = "http://schemas.microsoft.com/sharepoint/remoteapp/")]
    public class SPRemoteItemEventProperties
    {
        [DataMember]
        public Dictionary<string, object> AfterProperties
        {
            get;
            set;
        }

        [DataMember]
        public Dictionary<string, object> BeforeProperties
        {
            get;
            set;
        }

        [DataMember]
        public Guid ListId
        {
            get;
            set;
        }

        [DataMember]
        public int ListItemId
        {
            get;
            set;
        }

        [DataMember]
        public string ListTitle
        {
            get;
            set;
        }

        [DataMember]
        public string WebUrl
        {
            get;
            set;
        }

        [DataMember]
        public bool Versionless
        {
            get;
            set;
        }

        [DataMember]
        public string UserDisplayName
        {
            get;
            set;
        }

        [DataMember]
        public string UserLoginName
        {
            get;
            set;
        }

        [DataMember]
        public bool IsBackgroundSave
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentUserId
        {
            get;
            set;
        }

        [DataMember]
        public string BeforeUrl
        {
            get;
            set;
        }

        [DataMember]
        public string AfterUrl
        {
            get;
            set;
        }

        [DataMember]
        public byte[] ExternalNotificationMessage
        {
            get;
            set;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [DataContract(Namespace = "http://schemas.microsoft.com/sharepoint/remoteapp/")]
    public class SPRemoteListEventProperties
    {
        [DataMember]
        public string WebUrl
        {
            get;
            set;
        }

        [DataMember]
        public System.Guid ListId
        {
            get;
            set;
        }

        [DataMember]
        public string ListTitle
        {
            get;
            set;
        }

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string FieldName
        {
            get;
            set;
        }

        [DataMember]
        public string FieldXml
        {
            get;
            set;
        }

        [DataMember]
        public int TemplateId
        {
            get;
            set;
        }

        [DataMember]
        public System.Guid FeatureId
        {
            get;
            set;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [DataContract(Namespace = "http://schemas.microsoft.com/sharepoint/remoteapp/")]
    public class SPRemoteWebEventProperties
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string FullUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ServerRelativeUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string NewServerRelativeUrl { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    [DataContract(Name = "RemoteEntityEventProperties", Namespace = "http://schemas.microsoft.com/sharepoint/remoteapp/")]
    public partial class SPRemoteEntityInstanceEventProperties : object
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string EntityName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string EntityNamespace { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string NotificationContext { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string LobSystemInstanceName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        [SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public byte[] NotificationMessage { get; set; }
    }


    /// <summary>
    /// 
    /// </summary>
    [DataContract(Name = "RemoteEntityEventProperties", Namespace = "http://schemas.microsoft.com/sharepoint/remoteapp/")]
    public class SPRemoteEventResult
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public SPRemoteEventServiceStatus Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ErrorMessage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string RedirectUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public Dictionary<string, object> ChangedItemProperties
        {
            get
            {
                if (changedItemProperties == null)
                {
                    changedItemProperties = new Dictionary<string, object>();
                }

                return changedItemProperties;
            }
        }

        private Dictionary<string, object> changedItemProperties;
    }

    /// <summary>
    /// 
    /// </summary>
    [DataContract(Name = "RemoteEventProperties", Namespace = "http://schemas.microsoft.com/sharepoint/remoteapp/")]
    public class SPRemoteEventProperties
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public SPRemoteEventType EventType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public SPRemoteItemEventProperties ItemEventProperties { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public SPRemoteListEventProperties ListEventProperties { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public SPRemoteWebEventProperties WebEventProperties { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public SPRemoteEntityInstanceEventProperties EntityInstanceEventProperties { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    [ServiceContract(Namespace = "http://schemas.microsoft.com/sharepoint/remoteapp/")]
    public interface IRemoteEventService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="properties"></param>
        /// <returns></returns>
        [OperationContract]
        SPRemoteEventResult ProcessEvent(SPRemoteEventProperties properties);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="properties"></param>
        [OperationContract(IsOneWay = true)]
        void ProcessOneWayEvent(SPRemoteEventProperties properties);
    }
}
