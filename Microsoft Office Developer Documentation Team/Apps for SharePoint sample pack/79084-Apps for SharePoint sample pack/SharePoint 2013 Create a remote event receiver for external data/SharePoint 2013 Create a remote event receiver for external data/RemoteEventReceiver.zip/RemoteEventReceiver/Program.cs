﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Contoso.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            string siteUrl = "http://" + Environment.GetEnvironmentVariable("COMPUTERNAME") + ":8585";
           
            Console.WriteLine("Initializing service at " + siteUrl);
            using (ServiceHost host = new ServiceHost(typeof(Contoso.Test.RemoteEventService), new Uri(siteUrl)))
            {
                host.Open();
                host.Description.Behaviors.Find<ServiceAuthorizationBehavior>().ImpersonateCallerForAllOperations = true;
                Console.WriteLine("Started service at " + host.BaseAddresses[0].ToString());
                Console.WriteLine("Press <enter> to terminate  the Application");
                Console.ReadKey(true);
            }   
        }
    }
}
