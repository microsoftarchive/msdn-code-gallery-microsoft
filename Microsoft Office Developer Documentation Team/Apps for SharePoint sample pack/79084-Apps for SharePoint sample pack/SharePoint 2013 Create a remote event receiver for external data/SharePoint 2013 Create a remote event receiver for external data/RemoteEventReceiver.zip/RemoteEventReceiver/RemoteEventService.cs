﻿/********************************************************************
 * How to use this remote event receiver:
 *   1. Create a list.
 *   2. Add a single-line text column called 'Location' to the list.
 *   3. Register this remote event receiver to the list.
 *   
 * What does this remote event receiver do?
 *   It checks the value of 'Location',
 *   ruturns an error if the value is null,
 *   redirects to '/default.aspx' if the value is 'Redmond',
 *   or prepends '*** ' to the value.
 ********************************************************************/

using System;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Activation;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using Microsoft.SharePoint.Client;
using System.Text;
using System.Net.Mail;
using System.Web;

namespace Contoso.Test
{
    /// <summary>
    /// 
    /// </summary>
    public class RemoteEventService : IRemoteEventService
    {

        /// <summary>
        /// Custom test logic for event handler 
        /// </summary>
        /// <param name="properties">SPRemoteEventPropertiesWrapper</param>
        /// <returns></returns>
        public void ProcessOneWayEvent(SPRemoteEventProperties properties)
        {
            ProcessEvent(properties);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="properties"></param>
        /// <returns></returns>
        /// 
        public SPRemoteEventResult ProcessEvent(SPRemoteEventProperties properties)
        {
            SPRemoteEventResult result = null;
            ClientContext context = null;


            return result;
        }

    }
}